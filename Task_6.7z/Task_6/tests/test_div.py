import os
import pytest
import sys

sys.path.append(r'C:\\Users\\Professional\\Desktop\\Courses_logstream\\Task_6\\tests')
from test6_2 import merge_and_write
from conftest import setup_files

@pytest.mark.parametrize(
    "file1_path, file2_path, output_file_path, expected, result_exception",
    [
        ("test_file_1.txt", "test_file_2.txt", "new_test.txt", "Hello World", None),  # Valid case
        ("/nonexistent/path/to/file1.txt", "test_file_2.txt", "new_test.txt", "Один из файлов не найден", FileNotFoundError),  # Invalid file1
        ("test_file_1.txt", "/nonexistent/path/to/file2.txt", "new_test.txt", "Один из файлов не найден", FileNotFoundError),  # Invalid file2
        ("/nonexistent/path/to/file1.txt", "/nonexistent/path/to/file2.txt", "new_test.txt", "Один из файлов не найден", FileNotFoundError),  # Both files invalid
    ]
)
def test_merge_and_write(file1_path, file2_path, output_file_path, expected, result_exception, setup_files):
    test_file_1, test_file_2, output_file = setup_files

    # Use valid temporary files for valid file paths, but invalid paths for non-existent files
    file1_path = file1_path if "nonexistent" in file1_path else test_file_1
    file2_path = file2_path if "nonexistent" in file2_path else test_file_2
    output_file_path = output_file

    if result_exception:
        with pytest.raises(result_exception) as excinfo:
            merge_and_write(file1_path, file2_path, output_file_path)
        assert str(excinfo.value) == expected
    else:
        result = merge_and_write(file1_path, file2_path, output_file_path)
        assert result == expected







