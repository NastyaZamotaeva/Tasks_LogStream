import pytest
import os

@pytest.fixture
def setup_files(tmpdir):
    test_file_1 = tmpdir.join("test_file_1.txt")
    test_file_2 = tmpdir.join("test_file_2.txt")
    output_file = tmpdir.join("new_test.txt")

    test_file_1.write("Hello")
    test_file_2.write("World")

    return str(test_file_1), str(test_file_2), str(output_file)

  
