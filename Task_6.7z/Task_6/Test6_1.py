def average_num(list_num: list) -> float:
    if not list_num:
        return "Bad request"
    for ind, el in enumerate(list_num):
        if not isinstance(el, int | float):
            try:
                list_num[ind] = int(el)
            except:
                return "Bad request"
    return round(sum(list_num)/len(list_num), 2)

assert average_num([1,2,3,4,5]) == round(sum([1,2,3,4,5])/len([1,2,3,4,5]), 5)
assert average_num([1.2,2.2,3.2]) == round(sum([1.2,2.2,3.2])/len([1.2,2.2,3.2]), 3)
assert average_num(["asdfgh"]) == "Bad request"

assert average_num(['1','2','3','4','5']) == round(sum([1,2,3,4,5])/len([1,2,3,4,5]), 5)
assert average_num([1.0,2.0,3.0]) == round(sum([1.0,2.0,3.0])/len([1.0,2.0,3.0]), 3)
assert average_num(["1","2","3","4","5"]) == round(sum([1,2,3,4,5])/len([1,2,3,4,5]), 5)

assert average_num([]) == "Bad request"
assert average_num([1%5,2%5,3%5,4%5,5%5]) == round(sum([1%5,2%5,3%5,4%5,5%5])/len([1%5,2%5,3%5,4%5,5%5]), 5)
assert average_num(["a,s,d,f,g,h"]) == "Bad request"
assert average_num(['asdfgh']) == "Bad request"
