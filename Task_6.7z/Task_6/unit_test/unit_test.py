import unittest
import sys
sys.path.append(r'C:\\Users\\Professional\\Desktop\\Courses logstream\\Task 6\\unit_test')
from test6_3 import factorial

class TestFactorial(unittest.TestCase):
    def setUp(self) -> None:
        print("setUp")

    def test_factorial(self):
        self.assertRaises(ValueError,factorial,-1)
        self.assertEqual(factorial(0),1)
        self.assertEqual(factorial(4),24)
        self.assertRaises(ValueError,factorial,1000)
        

    def tearDown(self) -> None:
       print("tearDown")